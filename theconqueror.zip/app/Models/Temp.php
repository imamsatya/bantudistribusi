<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Temp extends Model
{
    use HasFactory;

    protected $fillable = [
        'kolom1',
        'kolom2',
        'kolom3',
        'kolom4',
        'kolom5',
        'kolom6',
        'kolom7',
        'kolom8',
        'kolom9',
        'kolom10',
        'kolom11',
        'kolom12'
    ];
}
